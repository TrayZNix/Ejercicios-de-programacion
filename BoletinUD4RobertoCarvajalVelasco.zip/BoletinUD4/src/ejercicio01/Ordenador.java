package ejercicio01;

public class Ordenador {
		private String marca;
		private String modelo;
		private double frencuenciaCPU;
		private double precioBase;
		private int capacidadAlmacenamiento;
		
		public Ordenador(String marca, String nombre, double frecuenciaCPU, double precioBase, int capacidadAlmacenamiento) {
			this.marca = marca;
			this.modelo = modelo;
			this.capacidadAlmacenamiento = capacidadAlmacenamiento;
			this.precioBase = precioBase;
			this.frencuenciaCPU = frecuenciaCPU;
		}
}
