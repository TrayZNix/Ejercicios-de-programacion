package ejemploAbstractas;

public abstract class Figura {

}
