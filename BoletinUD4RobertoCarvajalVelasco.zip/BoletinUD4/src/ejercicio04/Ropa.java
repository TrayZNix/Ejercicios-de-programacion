package ejercicio04;

public class Ropa extends Producto {

}
