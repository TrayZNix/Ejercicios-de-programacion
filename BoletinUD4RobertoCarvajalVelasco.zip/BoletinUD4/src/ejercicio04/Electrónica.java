package ejercicio04;

public class Electrónica extends Producto{
	

}
