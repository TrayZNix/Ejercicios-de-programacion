package ejercicio04;

public abstract class Producto {
	private double precioUnidad;
	private String nombre;
	static int codigoIdentificador;
}
