package ejercicio04;

public class Alimentacion extends Producto{
	private int diasHastaCaducidad;
	private int descuento;

}
